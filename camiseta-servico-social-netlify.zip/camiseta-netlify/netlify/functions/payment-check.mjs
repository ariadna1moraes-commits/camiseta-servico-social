export default async (req) => {
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);
  const handle = process.env.INFINITEPAY_HANDLE;
  if (!handle) return json({ error: "InfinitePay ainda não configurada no Netlify." }, 500);

  let body;
  try { body = await req.json(); } catch { return json({ error: "JSON inválido." }, 400); }

  const { order_nsu, transaction_nsu, slug } = body || {};
  if (!order_nsu || !transaction_nsu || !slug) {
    return json({ error: "Dados de confirmação incompletos." }, 400);
  }

  const response = await fetch("https://api.checkout.infinitepay.io/payment_check", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Accept": "application/json" },
    body: JSON.stringify({ handle, order_nsu, transaction_nsu, slug })
  });
  const data = await response.json().catch(() => ({}));
  return json(data, response.status);
};

export const config = { path: "/api/payment-check" };
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" }
  });
}
