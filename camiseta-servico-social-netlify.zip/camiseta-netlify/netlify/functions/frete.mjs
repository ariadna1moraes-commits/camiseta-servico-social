export default async (req) => {
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);

  const token = process.env.MELHOR_ENVIO_ACCESS_TOKEN;
  const originCep = digits(process.env.MELHOR_ENVIO_ORIGIN_CEP || "");
  const userAgent = process.env.MELHOR_ENVIO_USER_AGENT || "Loja Camiseta Servico Social (contato@exemplo.com)";

  if (!token || !originCep) {
    return json({ error: "Integração do Melhor Envio ainda não configurada no Netlify." }, 500);
  }

  let body;
  try { body = await req.json(); } catch { return json({ error: "JSON inválido." }, 400); }

  const destinationCep = digits(body.destinationCep || "");
  const quantity = Math.max(1, Math.min(20, Number(body.quantity) || 1));
  const product = body.product || {};

  if (originCep.length !== 8 || destinationCep.length !== 8) {
    return json({ error: "CEP de origem ou destino inválido." }, 400);
  }

  // Os dados abaixo são parâmetros de trabalho. Confirme peso e dimensões reais
  // antes da publicação comercial.
  const weight = Number(product.weightKg) || 0.30;
  const width = Number(product.widthCm) || 25;
  const height = Number(product.heightCm) || 8;
  const length = Number(product.lengthCm) || 35;
  const insurance = Number(product.insuranceValue) || 79.90;

  const payload = {
    from: { postal_code: originCep },
    to: { postal_code: destinationCep },
    products: [{
      id: "camiseta-servico-social",
      width,
      height,
      length,
      weight,
      insurance_value: insurance,
      quantity
    }]
  };

  const response = await fetch("https://melhorenvio.com.br/api/v2/me/shipment/calculate", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token}`,
      "Accept": "application/json",
      "Content-Type": "application/json",
      "User-Agent": userAgent
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    console.error("Melhor Envio error", response.status, data);
    return json({ error: "Não foi possível calcular o frete agora.", details: data }, response.status);
  }

  const options = Array.isArray(data) ? data
    .filter(x => x && !x.error)
    .map(x => ({
      id: x.id,
      name: x.name || x.company?.name || "Entrega",
      price: Number(x.custom_price ?? x.price ?? 0),
      deliveryTime: x.custom_delivery_time ?? x.delivery_time ? `${x.custom_delivery_time ?? x.delivery_time} dias úteis` : ""
    }))
    .filter(x => x.price > 0)
  : [];

  return json({ options });
};

export const config = { path: "/api/frete" };

function digits(v) { return String(v).replace(/\D/g, ""); }
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" }
  });
}
