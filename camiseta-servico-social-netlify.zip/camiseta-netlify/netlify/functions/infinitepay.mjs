export default async (req) => {
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);

  const handle = process.env.INFINITEPAY_HANDLE;
  if (!handle) return json({ error: "InfinitePay ainda não configurada no Netlify." }, 500);

  let body;
  try { body = await req.json(); } catch { return json({ error: "JSON inválido." }, 400); }

  const product = body.product || {};
  const shipping = body.shipping || {};
  const customer = body.customer || {};

  const quantity = Math.max(1, Math.min(20, Number(product.quantity) || 1));
  const unitPrice = 79.90;
  const shippingPrice = Math.max(0, Number(shipping.price) || 0);
  const total = unitPrice * quantity + shippingPrice;
  const orderNsu = `SS-${Date.now()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;

  const siteUrl = process.env.URL;
  const redirectUrl = `${siteUrl}/obrigado.html`;
  const webhookUrl = process.env.INFINITEPAY_WEBHOOK_URL || undefined;

  const payload = {
    handle,
    redirect_url: redirectUrl,
    order_nsu: orderNsu,
    customer: {
      name: customer.name || undefined,
      email: customer.email || undefined,
      phone_number: customer.phone || undefined
    },
    address: {
      cep: digits(customer.cep || ""),
      number: customer.number || undefined,
      complement: customer.complement || undefined
    },
    items: [
      {
        quantity,
        price: Math.round(unitPrice * 100),
        description: `${product.name || "Camiseta Serviço Social"} — ${product.fit || ""} — ${product.size || ""}`.trim()
      },
      ...(shippingPrice > 0 ? [{
        quantity: 1,
        price: Math.round(shippingPrice * 100),
        description: `Frete — ${shipping.name || "Entrega"}`
      }] : [])
    ]
  };

  if (webhookUrl) payload.webhook_url = webhookUrl;

  const response = await fetch("https://api.checkout.infinitepay.io/links", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Accept": "application/json" },
    body: JSON.stringify(payload)
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.url) {
    console.error("InfinitePay error", response.status, data);
    return json({ error: "Não foi possível criar o checkout da InfinitePay.", details: data }, response.status || 502);
  }

  return json({ url: data.url, order_nsu: orderNsu, total });
};

export const config = { path: "/api/infinitepay" };
function digits(v) { return String(v).replace(/\D/g, ""); }
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" }
  });
}
